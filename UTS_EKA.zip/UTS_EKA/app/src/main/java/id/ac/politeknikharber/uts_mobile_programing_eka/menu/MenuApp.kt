package id.ac.politeknikharber.uts_mobile_programing_eka.menu

data class MenuApp(var foto:Int=0, var nama:String=""){

}